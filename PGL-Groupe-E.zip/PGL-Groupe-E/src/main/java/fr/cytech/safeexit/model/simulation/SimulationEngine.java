package fr.cytech.safeexit.model.simulation;

import fr.cytech.safeexit.model.agent.Agent;
import fr.cytech.safeexit.model.agent.AgentState;
import fr.cytech.safeexit.model.graph.Edge;
import fr.cytech.safeexit.model.graph.Graph;
import fr.cytech.safeexit.model.graph.Node;
import fr.cytech.safeexit.model.graph.NodeType;
import fr.cytech.safeexit.model.observer.AbstractObservable;
import fr.cytech.safeexit.model.observer.Observer;
import fr.cytech.safeexit.model.observer.SimulationEvent;
import fr.cytech.safeexit.model.routing.VoronoiEvacuationRouter;
import fr.cytech.safeexit.model.sector.PanelMessage;
import fr.cytech.safeexit.model.sector.Sector;
import fr.cytech.safeexit.model.sector.SectorManager;
import fr.cytech.safeexit.model.sensor.SeatSensor;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Random;
import java.util.Set;

/**
 * Drives the simulation one cycle at a time.
 * <p>
 * Each call to {@link #tick()} advances every active agent by one step,
 * applying the "check before entering" capacity policy: an agent only steps
 * onto an edge if it still has room, otherwise it freezes for a couple of
 * cycles. Movement inside a node is instantaneous; bottlenecks happen on the
 * edges. The engine notifies observers of the events it produces and recomputes
 * the Voronoi routes when an obstacle appears.
 *
 * @author GROUPE E
 * @version 1.0
 */
public class SimulationEngine extends AbstractObservable implements Observer {

    /** Scales pixel distances into per-cycle progress. */
    private static final double SPEED_SCALE = 25.0;

    private final SimulationState state;
    private final Graph graph;
    private final VoronoiEvacuationRouter router;
    private final SimulationClock clock;

    private boolean paused;
    private boolean routesDirty;
    private EventPhase phase = EventPhase.NORMAL;
    private final Random random = new Random();

    /** Number of cycles between two attempts to send a spectator wandering. */
    private static final int AMBIENT_TRIP_INTERVAL = 6;
    /** Visual progress added per cycle while a wandering spectator crosses an edge. */
    private static final double AMBIENT_STEP = 0.34;
    /** Spectators currently away from their seat, with their remaining round-trip path. */
    private final Map<Agent, Deque<Node>> ambientRoutes = new HashMap<>();
    /** Home seat of each wandering spectator, to free/re-occupy only that seat. */
    private final Map<Agent, Node> ambientHome = new HashMap<>();
    /** Lazily-built list of "amenity" nodes (concourse / restrooms) agents walk to. */
    private List<Node> amenityCache;

    /**
     * Creates an engine for the given simulation state and computes the initial
     * routes.
     *
     * @param state the simulation state (graph and agents); never {@code null}
     */
    public SimulationEngine(SimulationState state) {
        if (state == null) {
            throw new IllegalArgumentException("Engine requires a simulation state");
        }
        this.state = state;
        this.graph = state.getGraph();
        this.router = new VoronoiEvacuationRouter(graph, state);
        this.clock = new SimulationClock();
        attachToModel();
        // The movement tracker records every AGENT_MOVED / AGENT_STATE_CHANGED event.
        addObserver(state.getAgentTracker());
        recomputeRoutes();
    }

    /**
     * Subscribes the engine to the graph and to every node and edge so it is
     * notified when something is blocked or unblocked.
     */
    private void attachToModel() {
        graph.addObserver(this);
        for (Node node : graph.getNodes()) {
            node.addObserver(this);
        }
        for (Edge edge : graph.getEdges()) {
            edge.addObserver(this);
        }
    }

    /**
     * Recomputes the Voronoi routes and refreshes each agent's assigned exit.
     */
    public void recomputeRoutes() {
        router.computeRoutes();
        for (Agent agent : state.getAgents()) {
            if (agent.getCurrentNode() != null) {
                agent.setTargetExit(state.getAssignedExit(agent.getCurrentNode()));
            }
        }
        routesDirty = false;
        notifyObservers(new SimulationEvent(SimulationEvent.Type.ROUTE_RECALCULATED, this));
    }

    /**
     * Advances the simulation by one cycle.
     */
    public void tick() {
        if (paused) {
            return;
        }
        if (routesDirty) {
            recomputeRoutes();
        }
        if (phase == EventPhase.NORMAL) {
            // Event in progress: only monitor the venue (ambient occupancy changes).
            ambientTick();
        } else {
            // Emergency: move every agent toward the exits.
            for (Agent agent : state.getAgents()) {
                stepAgent(agent);
            }
        }
        checkDensityAlerts();
        state.incrementCycle();
    }

    /**
     * Simulates the living venue during the {@link EventPhase#NORMAL} phase:
     * spectators occasionally leave their seat to walk to the concourse /
     * restrooms and come back. Each such agent physically travels the graph, so
     * the view shows a moving dot and the seat frees up (AWAY) then fills again
     * (OCCUPIED) when the spectator returns.
     */
    private void ambientTick() {
        // Advance every spectator currently away for a walk.
        for (Agent agent : new ArrayList<>(ambientRoutes.keySet())) {
            Deque<Node> route = ambientRoutes.get(agent);
            if (route != null) {
                ambientStep(agent, route);
            }
        }
        // Now and then, send another seated spectator on a round trip.
        maybeStartAmbientTrip();
    }

    /**
     * Advances one wandering agent by a single cycle. Ambient movement is purely
     * visual: it updates the agent's own position fields (so the canvas animates
     * a moving dot) and emits {@code AGENT_MOVED}, but it does <b>not</b> alter
     * node or edge occupancy except for the agent's own home seat. A spectator
     * may therefore shuffle past seated neighbours without disturbing them.
     *
     * @param agent the wandering agent
     * @param route its remaining path (ends back at its home seat)
     */
    private void ambientStep(Agent agent, Deque<Node> route) {
        // Currently crossing an edge: advance the dot visually.
        if (agent.getCurrentEdge() != null) {
            double progress = agent.getProgressOnEdge() + AMBIENT_STEP;
            if (progress < 1.0) {
                agent.setProgressOnEdge(progress);
                notifyObservers(new SimulationEvent(SimulationEvent.Type.AGENT_MOVED, agent));
                return;
            }
            Node arrived = agent.getEdgeDestination();
            agent.setCurrentEdge(null);
            agent.setEdgeDestination(null);
            agent.setProgressOnEdge(0.0);
            agent.setCurrentNode(arrived);
            notifyObservers(new SimulationEvent(SimulationEvent.Type.AGENT_MOVED, agent));
            if (route.isEmpty() && arrived != null && arrived.getType() == NodeType.SEAT) {
                finishAmbientTrip(agent);
            }
            return;
        }
        // Standing on a node: start crossing the next edge of the route.
        Node current = agent.getCurrentNode();
        if (current == null) {
            ambientRoutes.remove(agent);
            ambientHome.remove(agent);
            return;
        }
        if (route.isEmpty()) {
            finishAmbientTrip(agent);
            return;
        }
        Node next = route.pollFirst();
        if (next.equals(current)) {
            return;
        }
        Edge edge = graph.getEdgeBetween(current, next);
        if (edge == null) {
            finishAmbientTrip(agent);
            return;
        }
        boolean leavingHome = current.equals(ambientHome.get(agent));
        agent.setCurrentNode(null);
        agent.setCurrentEdge(edge);
        agent.setEdgeDestination(next);
        agent.setProgressOnEdge(0.0);
        if (leavingHome) {
            current.decrementAgentCount();
            if (state.getSensorNetwork() != null) {
                SeatSensor sensor = state.getSensorNetwork().getSensor(current);
                if (sensor != null) {
                    sensor.markAway(); // seat reserved while the spectator is out
                }
            }
        }
        notifyObservers(new SimulationEvent(SimulationEvent.Type.AGENT_MOVED, agent));
    }

    /**
     * Ends a round trip: the spectator sits back down on its home seat, which
     * becomes OCCUPIED again.
     *
     * @param agent the returning agent
     */
    private void finishAmbientTrip(Agent agent) {
        ambientRoutes.remove(agent);
        Node home = ambientHome.remove(agent);
        Node seat = (home != null) ? home : agent.getCurrentNode();
        if (seat != null && seat.getType() == NodeType.SEAT) {
            agent.setCurrentNode(seat);
            agent.setCurrentEdge(null);
            agent.setEdgeDestination(null);
            agent.setProgressOnEdge(0.0);
            seat.incrementAgentCount();
            if (state.getSensorNetwork() != null) {
                SeatSensor sensor = state.getSensorNetwork().getSensor(seat);
                if (sensor != null) {
                    sensor.markOccupied(agent);
                }
            }
        }
    }

    /**
     * Occasionally picks a seated, calm spectator and sends it on a round trip
     * to a random amenity node and back, within a small concurrency cap.
     */
    private void maybeStartAmbientTrip() {
        if (state.getCurrentCycle() % AMBIENT_TRIP_INTERVAL != 0) {
            return;
        }
        int cap = Math.max(1, state.getAgents().size() / 25);
        if (ambientRoutes.size() >= cap) {
            return;
        }
        List<Node> amenities = amenityNodes();
        if (amenities.isEmpty()) {
            return;
        }
        List<Agent> candidates = new ArrayList<>();
        for (Agent agent : state.getAgents()) {
            if (agent.hasExited() || ambientRoutes.containsKey(agent)
                    || agent.getState() != AgentState.CALM) {
                continue;
            }
            Node node = agent.getCurrentNode();
            if (node != null && node.getType() == NodeType.SEAT) {
                candidates.add(agent);
            }
        }
        if (candidates.isEmpty()) {
            return;
        }
        Agent agent = candidates.get(random.nextInt(candidates.size()));
        Node seat = agent.getCurrentNode();
        Node target = amenities.get(random.nextInt(amenities.size()));
        List<Node> forward = shortestPath(seat, target);
        List<Node> backward = shortestPath(target, seat);
        if (forward.isEmpty() || backward.isEmpty()) {
            return;
        }
        Deque<Node> route = new ArrayDeque<>();
        route.addAll(forward);
        route.addAll(backward);
        ambientRoutes.put(agent, route);
        ambientHome.put(agent, seat);
    }

    /**
     * Returns the nodes a wandering spectator can walk to (corridors and
     * intersections represent the concourse and restrooms). Cached after first use.
     *
     * @return the list of amenity nodes (possibly empty)
     */
    private List<Node> amenityNodes() {
        if (amenityCache == null) {
            amenityCache = new ArrayList<>();
            for (Node node : graph.getNodes()) {
                if ((node.getType() == NodeType.CORRIDOR
                        || node.getType() == NodeType.CROSS_SECTION)
                        && !node.isBlocked()) {
                    amenityCache.add(node);
                }
            }
        }
        return amenityCache;
    }

    /**
     * Breadth-first shortest path (in hops) between two nodes, avoiding blocked
     * nodes. The returned list excludes the start and ends at the target.
     *
     * @param start  the start node
     * @param target the target node
     * @return the path as a list of nodes, or an empty list if unreachable
     */
    private List<Node> shortestPath(Node start, Node target) {
        Map<Node, Node> previous = new HashMap<>();
        Set<Node> visited = new HashSet<>();
        Deque<Node> queue = new ArrayDeque<>();
        queue.add(start);
        visited.add(start);
        while (!queue.isEmpty()) {
            Node node = queue.poll();
            if (node.equals(target)) {
                break;
            }
            for (Node neighbour : graph.getNeighbors(node)) {
                if (visited.contains(neighbour) || neighbour.isBlocked()) {
                    continue;
                }
                visited.add(neighbour);
                previous.put(neighbour, node);
                queue.add(neighbour);
            }
        }
        if (!visited.contains(target)) {
            return new ArrayList<>();
        }
        Deque<Node> path = new ArrayDeque<>();
        for (Node node = target; node != null && !node.equals(start); node = previous.get(node)) {
            path.addFirst(node);
        }
        return new ArrayList<>(path);
    }

    /**
     * Triggers the emergency evacuation: switches to the evacuation phase and
     * notifies observers. Seated spectators (even those marked away) now head
     * for the exits.
     */
    public void triggerEvacuation() {
        if (phase == EventPhase.EVACUATION) {
            return;
        }
        phase = EventPhase.EVACUATION;
        // Any spectator currently wandering rushes back to their seat so the
        // evacuation starts from a clean, fully-seated state.
        for (Map.Entry<Agent, Node> entry : ambientHome.entrySet()) {
            Agent agent = entry.getKey();
            Node home = entry.getValue();
            agent.setCurrentEdge(null);
            agent.setEdgeDestination(null);
            agent.setProgressOnEdge(0.0);
            if (home != null) {
                agent.setCurrentNode(home);
                home.incrementAgentCount();
                if (state.getSensorNetwork() != null) {
                    SeatSensor sensor = state.getSensorNetwork().getSensor(home);
                    if (sensor != null) {
                        sensor.markOccupied(agent);
                    }
                }
            }
        }
        ambientHome.clear();
        ambientRoutes.clear();
        notifyObservers(new SimulationEvent(SimulationEvent.Type.EVACUATION_TRIGGERED, this));
    }

    /**
     * Returns the current event phase.
     *
     * @return the phase
     */
    public EventPhase getPhase() {
        return phase;
    }

    /**
     * Indicates whether an evacuation is in progress.
     *
     * @return {@code true} if the phase is {@link EventPhase#EVACUATION}
     */
    public boolean isEvacuating() {
        return phase == EventPhase.EVACUATION;
    }

    /**
     * Advances a single agent by one cycle.
     *
     * @param agent the agent to move
     */
    private void stepAgent(Agent agent) {
        if (agent.hasExited()) {
            return;
        }
        // Agent currently travelling along an edge: advance its progress.
        if (agent.getCurrentEdge() != null) {
            advanceOnEdge(agent);
            return;
        }
        // Frozen agent: wait, then retry by becoming calm again.
        if (agent.getState() == AgentState.FROZEN) {
            if (agent.canMove()) {
                agent.setState(AgentState.CALM);
            } else {
                agent.decrementDelay();
            }
            return;
        }
        // Agent standing on a node: decide where to go and try to enter an edge.
        Node current = agent.getCurrentNode();
        Node next = agent.chooseNextNode(graph, state);
        if (next == null || next.equals(current)) {
            return;
        }
        Edge edge = graph.getEdgeBetween(current, next);
        if (edge == null) {
            return;
        }
        if (edge.hasRoom() && !next.isBlocked()) {
            enterEdge(agent, current, edge, next);
        } else {
            // No room: wait a couple of cycles (heavy congestion).
            agent.setState(AgentState.FROZEN);
        }
    }

    /**
     * Makes an agent leave its node and step onto an edge.
     *
     * @param agent   the agent
     * @param from    the node it is leaving
     * @param edge    the edge it enters
     * @param toNode  the node at the other end of the edge
     */
    private void enterEdge(Agent agent, Node from, Edge edge, Node toNode) {
        from.decrementAgentCount();
        // Free the seat sensor in real time when its occupant leaves.
        if (from.getType() == fr.cytech.safeexit.model.graph.NodeType.SEAT
                && state.getSensorNetwork() != null) {
            state.getSensorNetwork().onAgentLeftSeat(from);
        }
        edge.onAgentEnter();
        agent.setCurrentNode(null);
        agent.setCurrentEdge(edge);
        agent.setEdgeDestination(toNode);
        agent.setProgressOnEdge(0.0);
        notifyObservers(new SimulationEvent(SimulationEvent.Type.AGENT_MOVED, agent));
    }

    /**
     * Advances an agent already travelling on an edge, handling arrival.
     *
     * @param agent the agent
     */
    private void advanceOnEdge(Agent agent) {
        Edge edge = agent.getCurrentEdge();
        double increment = (agent.getCurrentSpeed() * edge.getSpeedModifier() * SPEED_SCALE)
                / Math.max(1.0, edge.getLength());
        double progress = agent.getProgressOnEdge() + increment;

        if (progress < 1.0) {
            agent.setProgressOnEdge(progress);
            notifyObservers(new SimulationEvent(SimulationEvent.Type.AGENT_MOVED, agent));
            return;
        }

        // Arrived at the destination node.
        Node destination = agent.getEdgeDestination();
        edge.onAgentLeave();
        agent.setCurrentEdge(null);
        agent.setEdgeDestination(null);
        agent.setProgressOnEdge(0.0);
        agent.setCurrentNode(destination);
        destination.incrementAgentCount();

        if (destination.isExit()) {
            agent.setState(AgentState.EXITED);
            notifyObservers(new SimulationEvent(SimulationEvent.Type.AGENT_REACHED_EXIT, agent));
        } else {
            notifyObservers(new SimulationEvent(SimulationEvent.Type.AGENT_MOVED, agent));
        }
    }

    /**
     * Emits a density alert for every node currently in heavy congestion.
     */
    private void checkDensityAlerts() {
        for (Node node : graph.getNodes()) {
            if (node.isCongested()) {
                notifyObservers(new SimulationEvent(SimulationEvent.Type.DENSITY_ALERT, node));
            }
        }
    }

    /**
     * Manually triggers panic in a whole sector: every seated agent of that
     * sector switches to {@link AgentState#PANICKED} (and therefore to the
     * panicked behaviour strategy), and the sector panel shows an alert. This is
     * the supervisor's "create a situation" tool used in demonstrations.
     *
     * @param sectorId the sector identifier (e.g. "SEC_1")
     * @return the number of agents that switched to panic
     */
    public int triggerPanicInSector(String sectorId) {
        SectorManager manager = state.getSectorManager();
        if (manager == null) {
            return 0;
        }
        Sector sector = manager.getSectorById(sectorId);
        if (sector == null) {
            return 0;
        }
        Set<String> rows = new HashSet<>(sector.getRowLabels());
        int affected = 0;
        for (Agent agent : state.getAgents()) {
            if (agent.hasExited()) {
                continue;
            }
            Node node = agent.getCurrentNode();
            if (node != null && node.getType() == NodeType.SEAT
                    && rows.contains(rowLabelOf(node.getId()))) {
                agent.setState(AgentState.PANICKED);
                affected++;
            }
        }
        if (sector.getPanel() != null) {
            sector.getPanel().broadcast(PanelMessage.alert("MOUVEMENT DE PANIQUE \u2014 " + sectorId));
        }
        return affected;
    }

    /**
     * Extracts the row label from a seat identifier ("SEAT_A_3" -&gt; "A").
     *
     * @param seatId the seat identifier
     * @return the row label, or the whole id if it does not match the pattern
     */
    private static String rowLabelOf(String seatId) {
        String[] parts = seatId.split("_");
        return parts.length >= 2 ? parts[1] : seatId;
    }

    /**
     * Returns the number of agents that have reached an exit.
     *
     * @return the count of evacuated agents
     */
    public int countEvacuated() {
        int n = 0;
        for (Agent agent : state.getAgents()) {
            if (agent.hasExited()) {
                n++;
            }
        }
        return n;
    }

    /**
     * Indicates whether every agent has evacuated.
     *
     * @return {@code true} if all agents have exited
     */
    public boolean isEvacuationComplete() {
        return countEvacuated() == state.getAgents().size();
    }

    /**
     * Reacts to model events: marks the routes as needing a recompute when an
     * obstacle appears or disappears.
     *
     * @param event the event broadcast by the model
     */
    @Override
    public void update(SimulationEvent event) {
        if (event == null) {
            return;
        }
        switch (event.getType()) {
            case EDGE_BLOCKED, EDGE_UNBLOCKED, NODE_STATE_CHANGED -> routesDirty = true;
            default -> { /* ignored */ }
        }
    }

    /**
     * Returns the simulation state driven by this engine.
     *
     * @return the simulation state
     */
    public SimulationState getState() {
        return state;
    }

    /**
     * Returns the simulation clock.
     *
     * @return the clock
     */
    public SimulationClock getClock() {
        return clock;
    }

    /**
     * Indicates whether the simulation is paused.
     *
     * @return {@code true} if paused
     */
    public boolean isPaused() {
        return paused;
    }

    /**
     * Pauses or resumes the simulation.
     *
     * @param paused the new paused state
     */
    public void setPaused(boolean paused) {
        this.paused = paused;
    }
}